import React from "react";
import "./pop-up.styles.css";

const PopUp = () => (
    <div className="pop-up__container">

    </div>
)

export default PopUp;