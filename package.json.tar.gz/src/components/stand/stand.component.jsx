import React from "react";
import "./stand.styles.css";
import { connect } from "react-redux";
import MinusIcon from "../minus-icon/minus-icon.component";
import CogIcon from "../cog-icon/cog-icon.component";

const Stand = ({ pokemonTeam }) => (
  <div className="stand">
    <ul className="stand-list">
      {pokemonTeam.pokemons.length > 0
        ? pokemonTeam.pokemons.map((pokemon) => {
          console.log(pokemon)
            return (
              <li key={pokemon.name + " stand"} className="stand-list__element">
                <img src={pokemon.sprite} />
                <div>{pokemon.name}</div>
                <div className="stand-list__button-holder">
                    <MinusIcon />
                    <CogIcon />
                </div>
              </li>
            );
          })
        : null}
    </ul>
  </div>
);

const mapStateToProps = ({ pokemonTeam }) => ({
  pokemonTeam,
});

export default connect(mapStateToProps)(Stand);
