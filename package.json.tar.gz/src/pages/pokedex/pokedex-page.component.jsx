import React from "react";
import "./pokedex-page.styles.css";
import { getPokemonByNameFullList } from "../../utils/pokemonList";
import Stats from "../../components/stats/stats.component";

class PokedexPage extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      pokemon: "",
      wasLoaded: false,
    };
  }

  componentDidMount() {
    const pokemon = getPokemonByNameFullList(
      this.props.match.params.pokemonName
    );
    this.setState({ pokemon: pokemon, wasLoaded: true });
    console.log(pokemon);
  }

  render() {
    const { wasLoaded, pokemon } = this.state;
    return wasLoaded ? (
      <div className="pokedex-container">
        <Stats pokemon={pokemon} />
        <div className="pokedex-presentation-container">
          <img className="presentation-image" src={`${pokemon.sprite}`} />
        </div>
        <div className="pokedex-rating-container"></div>
      </div>
    ) : (
      <div></div>
    );
  }
}

export default PokedexPage;
