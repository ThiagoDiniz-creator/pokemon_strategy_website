export const userActionTypes = {
  SET_CURRENT_USER: "SET_CURRENT_USER",
};
